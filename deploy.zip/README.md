
# Nihal-Electronic-e-commerce-project

## User Authentication
- **Register**:  
  `POST http://localhost:8000/api/users/register`

- **Sign In**:  
  `POST http://localhost:8000/api/users/signin`

## Social Authentication
- **Google Login**:  
  `GET http://localhost:8000/api/auth/google`

- **Facebook Login**:  
  `GET http://localhost:8000/api/auth/facebook`

---

## Categories
- **Create Category**:  
  `POST http://localhost:8000/api/categories`

- **Get All Categories**:  
  `GET http://localhost:8000/api/categories`

- **Get Single Category**:  
  `GET http://localhost:8000/api/categories/:category_id`

- **Update Category**:  
  `PUT http://localhost:8000/api/categories/:category_id`

- **Delete Category**:  
  `DELETE http://localhost:8000/api/categories/:category_id`

---

## Products
- **Create Product**:  
  `POST http://localhost:8000/api/products`

- **Get All Products**:  
  `GET http://localhost:8000/api/products`

- **Get Single Product**:  
  `GET http://localhost:8000/api/products/:product_id`

- **Update Product**:  
  `PUT http://localhost:8000/api/products/:product_id`

- **Delete Product**:  
  `DELETE http://localhost:8000/api/products/:product_id`

---

## Product Images
- **Add Product Image**:  
  `POST http://localhost:8000/api/products/:product_id/images`

- **Get All Images for Product**:  
  `GET http://localhost:8000/api/products/:product_id/images`

- **Get Single Image**:  
  `GET http://localhost:8000/api/products/:product_id/images/:image_id`

- **Update Image**:  
  `PUT http://localhost:8000/api/products/:product_id/images/:image_id`

- **Delete Image**:  
  `DELETE http://localhost:8000/api/products/:product_id/images/:image_id`

---

## Environment Variables (`.env`)
```env
DATABASE_URL="mysql://root:1234@localhost:3306/ElectroShop"
PORT=8000
GOOGLE_CLIENT_ID="645889207349-09hdhs2bc.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET="GOCSPX-tFhTs1VPYPrb2b"
FACEBOOK_CLIENT_ID=your_facebook_app_id
FACEBOOK_CLIENT_SECRET=your_facebook_app_secret
JWT_SECRET="/slBa/Ifb2Obf7j1n/+qe7P6bgMxDAwszevFgFsOOJ8lWjDEnBeNSvM3NnZ/UeQhYmAduixRAPF0R+NkAbJDSA=="



To run your Node.js project:

Install dependencies
Open a terminal in your backend folder and run:

Set up environment variables
Make sure your .env file is present and configured (as shown in your README).

Run database migrations (if using Prisma):

Start the server:

or, for development with auto-reload:

Your server should now be running at http://localhost:8000.